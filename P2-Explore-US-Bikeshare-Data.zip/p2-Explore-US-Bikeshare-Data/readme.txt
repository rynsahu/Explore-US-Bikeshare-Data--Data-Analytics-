***************************************************
About Project:
***************************************************
Explore US Bikeshare Data: 

In this project, I use of Python to 
explore data related to bike share systems for three 
major cities in the United States�Chicago, New York City, 
and Washington. I write code to import the data 
and answer interesting questions about it by computing 
descriptive statistics. I also write a script 
that takes in raw input to create an interactive 
experience in the terminal to present these 
statistics.

***************************************************
Other resources:
***************************************************
1. www.tutorialspoint.com/python3/
2. www.programiz.com/python-programming/
3. www.tackoverflow.com/

***************************************************
Tools and software:
***************************************************
1. Atom
2. Anaconda
3. Juypter notebook
4. Pandas

Author: Arayan sahu